<?php 
session_start();
 
// cek apakah yang mengakses halaman ini sudah login
if($_SESSION['level']==""){
    header("location:index.php?pesan=gagal");
}

require 'functions2.php';
$transaksi = query("SELECT * FROM transaksi");

// tombol cari ditekan
if( isset($_POST["cari"]) ) {
    $transaksi = cari($_POST["keyword"]);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Halaman Transaksi</title>
    <link rel="stylesheet" type="text/css" href="style2.css">
    <!-- Tambahkan link FontAwesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body>

<h1>Daftar Transaksi</h1>
<center>
    <br>
    <table border="1" cellpadding="10" width="100%">
        <tr>
            <th>No.</th>
            <th>Tanggal</th>
            <th>Keterangan</th>
            <th>Debet</th>
            <th>Kredit</th>            
        </tr>
        <?php $i = 1; ?>
        <?php foreach( $transaksi as $row ) : ?>
        <tr>
            <td><?= $i; ?></td>
            <td><?php echo $row['tanggaltransaksi']; ?></td>
            <td><?php echo $row['keterangan']; ?></td>
            <td>Rp <?php echo $row['debet']; ?></td>
            <td>Rp <?php echo $row['kredit']; ?></td>     
        </tr>
        <?php $i++; ?>
        <?php endforeach; ?>
    </table>
</center>
<script>
    window.print();
</script>
</body>
</html>
