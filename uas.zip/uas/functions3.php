<?php 
// koneksi ke database
$conn = mysqli_connect("localhost", "root", "", "toko");


function query($query) {
	global $conn;
	$result = mysqli_query($conn, $query);
	$rows = [];
	while( $row = mysqli_fetch_assoc($result) ) {
		$rows[] = $row;
	}
	return $rows;
}
 

function tambah($data) {
	global $conn;

	$tanggaltransaksi = ($data["tanggaltransaksi"]);
	$keterangan = ($data["keterangan"]);
	$debet = ($data["debet"]);
	$kredit = ($data["kredit"]);
	

	$query = "INSERT INTO transaksi
				VALUES
			  ('', '$tanggaltransaksi', '$keterangan', '$debet', '$kredit')
			";
	mysqli_query($conn, $query);

	return mysqli_affected_rows($conn);
}



function hapus($id) {
	global $conn;
	mysqli_query($conn, "DELETE FROM transaksi WHERE id = $id");
	return mysqli_affected_rows($conn);
}


function ubah($data) {
	global $conn;

	$id = $data["id"];
	$tanggaltransaksi = ($data["tanggaltransaksi"]);
	$keterangan = ($data["keterangan"]);
	$debet = ($data["debet"]);
	$kredit = ($data["kredit"]);
	

	$query = "UPDATE transaksi SET
				tanggaltransaksi = '$tanggaltransaksi',
				keterangan = '$keterangan',
				debet = '$debet',
				kredit = '$kredit'
			  WHERE id = $id
			";

	mysqli_query($conn, $query);

	return mysqli_affected_rows($conn);	
}


function cari($keyword) {
	$query = "SELECT * FROM transaksi
				WHERE
			  keterangan LIKE '%$keyword%' OR
			  tanggaltransaksi LIKE '%$keyword%' OR
			  debet LIKE '%$keyword%' OR
			  kredit LIKE '%$keyword%'
			";
	return query($query);
}


?>
